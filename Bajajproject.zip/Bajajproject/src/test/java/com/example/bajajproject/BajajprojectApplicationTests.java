package com.example.bajajproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BajajprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
